exports.id = 24;
exports.ids = [24];
exports.modules = {

/***/ 5405:
/***/ ((module) => {

// Exports
module.exports = {
	"AdminWrapperSection": "AdminWrapper_AdminWrapperSection__KiLUr",
	"AdminListWrapper": "AdminWrapper_AdminListWrapper___1VNW",
	"EditClientModalWrapper": "AdminWrapper_EditClientModalWrapper__4n1If",
	"CompositionListWrapper": "AdminWrapper_CompositionListWrapper__4G0Wx",
	"CreateUsersContainerWrapper": "AdminWrapper_CreateUsersContainerWrapper__KejXn",
	"UsersListContainerWrapper": "AdminWrapper_UsersListContainerWrapper__G3Bdc",
	"EditClientNameContainer": "AdminWrapper_EditClientNameContainer__1C9wY",
	"EditClientConfigContainer": "AdminWrapper_EditClientConfigContainer__3aO8s",
	"EditClientConfigBtnsContainer": "AdminWrapper_EditClientConfigBtnsContainer___Uaf_",
	"CompositionsConfigWrapper": "AdminWrapper_CompositionsConfigWrapper__RjDWl",
	"CreateCompositionWrapper": "AdminWrapper_CreateCompositionWrapper__U3DM3",
	"EditSubCompAccordionWrapper": "AdminWrapper_EditSubCompAccordionWrapper__6LuX8",
	"editCompositionWrapper": "AdminWrapper_editCompositionWrapper__ZKyjq",
	"OutputsWrapper": "AdminWrapper_OutputsWrapper__P2rU1",
	"AdminLoginPage": "AdminWrapper_AdminLoginPage__L3Ntk",
	"ClientLoginPage": "AdminWrapper_ClientLoginPage___gPP4",
	"VenuesScanWrapper": "AdminWrapper_VenuesScanWrapper__VJAxx"
};


/***/ }),

/***/ 9856:
/***/ ((module) => {

// Exports
module.exports = {
	"ErrorComponent": "Error_ErrorComponent__1k78x"
};


/***/ }),

/***/ 2075:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "q": () => (/* binding */ AdminWrapper)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _AdminWrapper_module_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5405);
/* harmony import */ var _AdminWrapper_module_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_AdminWrapper_module_css__WEBPACK_IMPORTED_MODULE_2__);



function AdminWrapper(props) {
    const { wrapperClass , className  } = props;
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: `${className} ${(_AdminWrapper_module_css__WEBPACK_IMPORTED_MODULE_2___default())[wrapperClass]}`,
        children: props.children
    });
}



/***/ }),

/***/ 8895:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "j": () => (/* binding */ Error)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react_bootstrap_Alert__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2899);
/* harmony import */ var react_bootstrap_Alert__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap_Alert__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Error_module_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9856);
/* harmony import */ var _Error_module_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_Error_module_css__WEBPACK_IMPORTED_MODULE_2__);



function Error(props) {
    const { setError , errorInfo  } = props;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Alert__WEBPACK_IMPORTED_MODULE_1___default()), {
        variant: "danger",
        onClose: ()=>setError(false),
        dismissible: true,
        className: `${(_Error_module_css__WEBPACK_IMPORTED_MODULE_2___default().ErrorComponent)}`,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Alert__WEBPACK_IMPORTED_MODULE_1___default().Heading), {
                children: "Error"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                children: JSON.stringify(errorInfo)
            })
        ]
    });
}



/***/ })

};
;