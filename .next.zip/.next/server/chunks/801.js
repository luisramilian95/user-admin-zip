"use strict";
exports.id = 801;
exports.ids = [801];
exports.modules = {

/***/ 5736:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "_": () => (/* binding */ useLocalStorage)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

function useLocalStorage(itemName, initialValue) {
    const [error, setError] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
    const [item, setItem] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(initialValue);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        try {
            const localStorageItem = localStorage.getItem(itemName);
            let parsedItem;
            if (!localStorageItem) {
                localStorage.setItem(itemName, JSON.stringify(initialValue));
                parsedItem = initialValue;
            } else {
                parsedItem = JSON.parse(localStorageItem);
            }
            setItem(parsedItem);
            setLoading(false);
        } catch (error) {
            setError(error);
        }
    }, []);
    const saveItem = (newItem)=>{
        try {
            const stringifiedItem = JSON.stringify(newItem);
            localStorage.setItem(itemName, stringifiedItem);
            setItem(newItem);
        } catch (error) {
            setError(error);
        }
    };
    return {
        item,
        saveItem,
        loading,
        error
    };
}



/***/ }),

/***/ 1801:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "H": () => (/* binding */ AuthProvider),
/* harmony export */   "V": () => (/* binding */ AuthContext)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Hooks_LocalStorage_useLocalStorage__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5736);
/* harmony import */ var _services_fetchAdminData__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6664);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_services_fetchAdminData__WEBPACK_IMPORTED_MODULE_3__]);
_services_fetchAdminData__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const AuthContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)();
function AuthProvider({ children  }) {
    const { item: accessToken , saveItem: setAccessToken , loading: accessTokenLoading , error: accessTokenError  } = (0,_Hooks_LocalStorage_useLocalStorage__WEBPACK_IMPORTED_MODULE_2__/* .useLocalStorage */ ._)("accessToken", null);
    const { item: singularToken , saveItem: setSingularToken , loading: singularTokenLoading , error: singularTokenError  } = (0,_Hooks_LocalStorage_useLocalStorage__WEBPACK_IMPORTED_MODULE_2__/* .useLocalStorage */ ._)("singularToken", null);
    // User Authentication
    const login = (newToken)=>{
        setAccessToken(newToken);
    };
    const logout = ()=>{
        setAccessToken(null);
    };
    const getAccessToken = ()=>{
        const accessToken = JSON.parse(localStorage.getItem("accessToken"));
        setAccessToken(accessToken);
        return accessToken;
    };
    // Singular API Token
    const generateSingularToken = (singularToken)=>{
        setSingularToken(singularToken);
    };
    const getSingularToken = ()=>{
        const singularToken = JSON.parse(localStorage.getItem("singularToken"));
        setSingularToken(singularToken);
        return singularToken;
    };
    const refreshToken = async (singularToken)=>{
        const newToken = await (0,_services_fetchAdminData__WEBPACK_IMPORTED_MODULE_3__/* .refreshSingularToken */ .Tm)(singularToken.refreshToken);
        let updateSingularToken = await JSON.parse(localStorage.getItem("singularToken"));
        localStorage.removeItem("singularToken");
        updateSingularToken.accessToken = newToken.accessToken;
        updateSingularToken.tokenExpiration = Date.now() + 10 * 24 * 60 * 60 * 1000;
        setSingularToken(updateSingularToken);
    };
    const value = {
        accessToken,
        setAccessToken,
        getAccessToken,
        login,
        logout,
        generateSingularToken,
        refreshToken,
        singularToken,
        setSingularToken,
        getSingularToken
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(AuthContext.Provider, {
        value: value,
        children: children
    });
}


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6664:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$s": () => (/* binding */ getSingularToken),
/* harmony export */   "CO": () => (/* binding */ getCompositions),
/* harmony export */   "E0": () => (/* binding */ duplicateAppInstance),
/* harmony export */   "Eu": () => (/* binding */ deleteAppInstance),
/* harmony export */   "NZ": () => (/* binding */ updateVenue),
/* harmony export */   "Nq": () => (/* binding */ updateUser),
/* harmony export */   "Nu": () => (/* binding */ deleteClient),
/* harmony export */   "O6": () => (/* binding */ updateAppInstance),
/* harmony export */   "Qu": () => (/* binding */ updateClient),
/* harmony export */   "Tm": () => (/* binding */ refreshSingularToken),
/* harmony export */   "Up": () => (/* binding */ getApiVenueInfo),
/* harmony export */   "VW": () => (/* binding */ getApiVenues),
/* harmony export */   "W2": () => (/* binding */ UpdateComposition),
/* harmony export */   "XG": () => (/* binding */ updateOutput),
/* harmony export */   "XP": () => (/* binding */ deleteComposition),
/* harmony export */   "ZJ": () => (/* binding */ createVenue),
/* harmony export */   "ZL": () => (/* binding */ getClients),
/* harmony export */   "ce": () => (/* binding */ updateClientCompositionConfig),
/* harmony export */   "dH": () => (/* binding */ createOutput),
/* harmony export */   "eI": () => (/* binding */ createClient),
/* harmony export */   "eZ": () => (/* binding */ createClientCompositionConfig),
/* harmony export */   "h8": () => (/* binding */ deleteUser),
/* harmony export */   "ho": () => (/* binding */ getVenues),
/* harmony export */   "lV": () => (/* binding */ updateDataStream),
/* harmony export */   "ng": () => (/* binding */ deleteDataStream),
/* harmony export */   "nq": () => (/* binding */ retrieveClient),
/* harmony export */   "nt": () => (/* binding */ createSubComposition),
/* harmony export */   "pH": () => (/* binding */ loginUser),
/* harmony export */   "qw": () => (/* binding */ deleteOutput),
/* harmony export */   "r4": () => (/* binding */ createUser),
/* harmony export */   "s4": () => (/* binding */ createComposition),
/* harmony export */   "sJ": () => (/* binding */ retrieveUser),
/* harmony export */   "u9": () => (/* binding */ createDataStream)
/* harmony export */ });
/* unused harmony exports getData, postData, deleteData, updateData, getAdminClients, deleteClientCompositionConfig, getAdminUsers, getSubcompositions */
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const api = axios__WEBPACK_IMPORTED_MODULE_0__["default"].create({
    headers: {
        "Content-Type": "application/json"
    }
});
const getData = async (params)=>{
    try {
        const response = await api.get(params);
        return response.data;
    } catch (error) {
        return error;
    }
};
const postData = async (params, body = {}, accessToken)=>{
    try {
        const response = await api.post(params, body, {
            headers: {
                Authorization: `Bearer ${accessToken}`
            }
        });
        return response.data;
    } catch (error) {
        console.log({
            error
        });
        return error;
    }
};
const deleteData = async (params, accessToken)=>{
    try {
        const response = await api.delete(params, {
            headers: {
                Authorization: `Bearer ${accessToken}`
            }
        });
        return response.data;
    } catch (error) {
        return error;
    }
};
const updateData = async (params, body, accessToken)=>{
    try {
        const response = await api.patch(params, body, {
            headers: {
                Authorization: `Bearer ${accessToken}`
            }
        });
        return response.data;
    } catch (error) {
        return error;
    }
};
// Clients
const getClients = async ()=>{
    let params = `/api/clients`;
    return await getData(params);
};
// Retrieve client
const retrieveClient = async (clientId)=>{
    let params = `/api/clients?clientId=${clientId}`;
    return await getData(params);
};
// Get Admin Client
const getAdminClients = async ()=>{
    let params = `/api/clients?isAdminClient=${true}`;
    return await getData(params);
};
// Create Client
const createClient = async (body, accessToken)=>{
    let params = `/api/clients`;
    return await postData(params, body, accessToken);
};
// Delete client
const deleteClient = async (clientId, accessToken)=>{
    let params = `/api/clients?clientId=${clientId}`;
    return await deleteData(params, accessToken);
};
// Update client
const updateClient = async (clientId, body, accessToken)=>{
    const params = `/api/clients?clientId=${clientId}`;
    return await updateData(params, body, accessToken);
};
// Create client composition related with client
const createClientCompositionConfig = async (clientId, compositionId, body, accessToken)=>{
    let params = `/api/clients/composition-config?clientId=${clientId}&compositionId=${compositionId}`;
    return await postData(params, body, accessToken);
};
// Update client composition related with client
const updateClientCompositionConfig = async (clientId, compositionId, body, accessToken)=>{
    let params = `/api/clients/composition-config?clientId=${clientId}&compositionId=${compositionId}`;
    return await updateData(params, body, accessToken);
};
// Delete client composition related with client
const deleteClientCompositionConfig = async (clientId, compositionId)=>{
    let params = `/api/clients/composition-config?clientId=${clientId}&compositionId=${compositionId}`;
    return await deleteData(params);
};
// Get admin users
const getAdminUsers = async ()=>{
    const params = `/api/auth/users/?isAdmin=true`;
    return await getData(params);
};
// Create user
const createUser = async (body, accessToken)=>{
    // to create a client user body needs clientId
    const params = `/api/auth/users`;
    return await postData(params, body, accessToken);
};
// Delete user
const deleteUser = async (username, accessToken)=>{
    const params = `/api/auth/users?username=${username}`;
    return await deleteData(params, accessToken);
};
// Update user
const updateUser = async (username, body, accessToken)=>{
    const params = `/api/auth/users?username=${username}`;
    return await updateData(params, body, accessToken);
};
// Retrieve user
const retrieveUser = async (username)=>{
    const params = `/api/auth/users?username=${username}`;
    return await getData(params);
};
// Login user
const loginUser = async (body)=>{
    const params = `/api/auth/login`;
    return await postData(params, body);
};
// Get compositions
const getCompositions = async ()=>{
    let params = `/api/compositions`;
    return await getData(params);
};
// Create Composition
const createComposition = async (body, accessToken)=>{
    let params = `/api/compositions`;
    return await postData(params, body, accessToken);
};
// Update composition
const UpdateComposition = async (compositionId, body, accessToken)=>{
    const params = `/api/compositions?compositionId=${compositionId}`;
    return updateData(params, body, accessToken);
};
// Delete composition
const deleteComposition = async (compositionId, accessToken)=>{
    const params = `/api/compositions?compositionId=${compositionId}`;
    return deleteData(params, accessToken);
};
// Get list of Venues
const getVenues = async ()=>{
    let params = `/api/venues`;
    return await getData(params);
};
//Create Venue
const createVenue = async (body, accessToken)=>{
    let params = `/api/venues`;
    return await postData(params, body, accessToken);
};
// Update Venue
const updateVenue = async (venueId, body, accessToken)=>{
    let params = `/api/venues?venueId=${venueId}`;
    return await updateData(params, body, accessToken);
};
// Get Api venues
let apiKey = "KcqNYhGtIh8r7cj7kIMys3YJIfGiCvmr7dTuUPuH";
const getApiVenues = async ()=>{
    let url = "https://hy8ix63kw2.execute-api.ap-southeast-2.amazonaws.com/Dev/getvenues";
    let res = await axios__WEBPACK_IMPORTED_MODULE_0__["default"].get(url, {
        headers: {
            "x-api-key": apiKey
        }
    });
    return res.data;
};
// Get Api venues Information
const getApiVenueInfo = async (externalVenueId)=>{
    let url = `https://hy8ix63kw2.execute-api.ap-southeast-2.amazonaws.com/Dev/getvenue?ExternalVenueId=${externalVenueId}`;
    let res = await axios__WEBPACK_IMPORTED_MODULE_0__["default"].get(url, {
        headers: {
            "x-api-key": apiKey
        }
    });
    return res.data;
};
// get SubCompositions
const getSubcompositions = async ()=>{
    let params = `/api/subcompositions`;
    return await getData(params);
};
// Create SubComposition
const createSubComposition = async (body, accessToken)=>{
    let params = `/api/subcompositions`;
    return await postData(params, body, accessToken);
};
const getSingularToken = async ()=>{
    const url = `https://app.singular.live/apiv2/users/logintoken`;
    const body = {
        email: "lesliekajomovitz@gmail.com",
        password: "cybulalau26"
    };
    try {
        const res = await axios__WEBPACK_IMPORTED_MODULE_0__["default"].post(url, body);
        return res.data;
    } catch (error) {
        console.log(error);
        return error;
    }
};
const refreshSingularToken = async (refreshToken)=>{
    const url = `https://app.singular.live/apiv2/users/refreshtoken`;
    let body = {
        refreshToken: refreshToken
    };
    try {
        const res = await axios__WEBPACK_IMPORTED_MODULE_0__["default"].post(url, body);
        return res.data;
    } catch (error) {
        return error;
    }
};
// Duplicate singular app instance
const duplicateAppInstance = async (appInstanceId, body, singularToken)=>{
    const url = `https://app.singular.live/apiv2/controlapps/${appInstanceId}/duplicate`;
    try {
        const res = await axios__WEBPACK_IMPORTED_MODULE_0__["default"].post(url, body, {
            headers: {
                Authorization: `Bearer ${singularToken}`
            }
        });
        return res.data;
    } catch (error) {
        return error;
    }
};
// update AppInstance
const updateAppInstance = async (appInstanceId, body, singularToken)=>{
    const url = `https://app.singular.live/apiv2/controlapps/${appInstanceId}`;
    try {
        const res = await axios__WEBPACK_IMPORTED_MODULE_0__["default"].patch(url, body, {
            headers: {
                Authorization: `Bearer ${singularToken}`
            }
        });
        return res.data;
    } catch (error) {
        console.log(error);
        return error;
    }
};
// Delete AppInstance
const deleteAppInstance = async (appInstanceId, singularToken)=>{
    const url = `https://app.singular.live/apiv2/controlapps/${appInstanceId}`;
    try {
        const res = await axios__WEBPACK_IMPORTED_MODULE_0__["default"]["delete"](url, {
            headers: {
                Authorization: `Bearer ${singularToken}`
            }
        });
        return res.data;
    } catch (error) {
        console.log(error);
        return error;
    }
};
const headers = {
    Authorization: `Basic ${Buffer.from(`${"lesliekajomovitz@gmail.com"}:${"cybulalau26"}`).toString("base64")}`
};
// Create Datastream
const createDataStream = async (body)=>{
    const url = `https://app.singular.live/apiv1/datastreams`;
    try {
        const res = await axios__WEBPACK_IMPORTED_MODULE_0__["default"].post(url, body, {
            headers
        });
        return res.data;
    } catch (error) {
        return error;
    }
};
// Update Datastream
const updateDataStream = async (datastreamId, body)=>{
    const url = `https://app.singular.live/apiv1/datastreams/${datastreamId}`;
    try {
        const res = await axios__WEBPACK_IMPORTED_MODULE_0__["default"].put(url, body, {
            headers
        });
        return res.data;
    } catch (error) {
        console.log(error);
        return error;
    }
};
// Delete Datastream
const deleteDataStream = async (datastreamId)=>{
    const url = `https://app.singular.live/apiv1/datastreams/${datastreamId}`;
    try {
        const res = await axios__WEBPACK_IMPORTED_MODULE_0__["default"]["delete"](url, {
            headers
        });
        return res.data;
    } catch (error) {
        return error;
    }
};
// Create Output
const createOutput = async (body, accessToken)=>{
    let params = `/api/outputs`;
    return await postData(params, body, accessToken);
};
// Update Output
const updateOutput = async (outputId, body, accessToken)=>{
    let params = `/api/outputs?outputId=${outputId}`;
    return await updateData(params, body, accessToken);
};
// Delete Output
const deleteOutput = async (outputId, accessToken)=>{
    let params = `/api/outputs?outputId=${outputId}`;
    return await deleteData(params, accessToken);
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;