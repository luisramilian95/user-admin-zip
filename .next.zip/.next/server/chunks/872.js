"use strict";
exports.id = 872;
exports.ids = [872];
exports.modules = {

/***/ 7309:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DI": () => (/* binding */ ActionModalLoader),
/* harmony export */   "JT": () => (/* binding */ MainAppLoader),
/* harmony export */   "Ze": () => (/* binding */ ActionsLoader)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_bootstrap_Modal__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9306);
/* harmony import */ var react_bootstrap_Modal__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap_Modal__WEBPACK_IMPORTED_MODULE_2__);



const spinAnimation = styled_components__WEBPACK_IMPORTED_MODULE_1__.keyframes`
  0% {
    transform: rotate(0deg);
  }

  100% {
    transform: rotate(360deg);
  }
`;
const CircularLoader = styled_components__WEBPACK_IMPORTED_MODULE_1___default().div.withConfig({
    componentId: "sc-df7a3ce7-0"
})`
  border: 0.25rem solid rgba(0, 0, 0, 0.1);
  width: 6.25rem;
  height: 6.25rem;
  border-radius: 50%;
  border-left-color: #0099b8cc;
  animation: ${spinAnimation} 3s linear infinite;
`;
const LoaderParent = styled_components__WEBPACK_IMPORTED_MODULE_1___default().div.withConfig({
    componentId: "sc-df7a3ce7-1"
})`
  display: -webkit-inline-box;
`;
const MainModalLoader = styled_components__WEBPACK_IMPORTED_MODULE_1___default().div.withConfig({
    componentId: "sc-df7a3ce7-2"
})`
  left: auto;
  top: 40%;
  width: -webkit-fill-available;
  width: -moz-available;
  text-align: -webkit-center;
  text-align: -moz-center;
  margin-bottom: 20px;
`;
const MainLoader = styled_components__WEBPACK_IMPORTED_MODULE_1___default().div.withConfig({
    componentId: "sc-df7a3ce7-3"
})`
  position: absolute;
  left: auto;
  top: 40%;
  width: -webkit-fill-available;
  width: -moz-available;
  text-align: -webkit-center;
  text-align: -moz-center;
`;
const SwitchCircularLoader = styled_components__WEBPACK_IMPORTED_MODULE_1___default().div.withConfig({
    componentId: "sc-df7a3ce7-4"
})`
  border: 0.25rem solid rgba(0, 0, 0, 0.1);
  width: ${(props)=>props.loaderSize === "lg" ? "6.25rem" : props.loaderSize === "md" ? "3rem" : "1.5rem"};
  height: ${(props)=>props.loaderSize === "lg" ? "6.25rem" : props.loaderSize === "md" ? "3rem" : "1.5rem"};
  border-radius: 50%;
  border-left-color: #0099b8cc;
  animation: ${spinAnimation} 3s linear infinite;
`;
const MainSwitchLoader = styled_components__WEBPACK_IMPORTED_MODULE_1___default().div.withConfig({
    componentId: "sc-df7a3ce7-5"
})`
  width: ${(props)=>props.loaderSize === "switch" ? "" : "-webkit-fill-available"};
  width: ${(props)=>props.loaderSize === "switch" ? "" : "-moz-available"};
  margin-left: ${(props)=>props.loaderSize === "switch" ? "10px" : ""};
  margin-top: ${(props)=>props.loaderSize === "switch" ? "1px" : ""};
  text-align: -webkit-center;
  text-align: -moz-center;
`;
const ActionsLoader = (props)=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(MainSwitchLoader, {
        loaderSize: props.loaderSize,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(LoaderParent, {
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(SwitchCircularLoader, {
                loaderSize: props.loaderSize
            })
        })
    });
};
const MainAppLoader = (props)=>{
    const { text  } = props;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(MainLoader, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(LoaderParent, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(CircularLoader, {})
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                children: text
            })
        ]
    });
};
const ActionModalLoader = (props)=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Modal__WEBPACK_IMPORTED_MODULE_2___default()), {
        show: props.show,
        onHide: props.closeModal,
        backdrop: "static",
        size: "lg",
        "aria-labelledby": "contained-modal-title-vcenter",
        centered: true,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Modal__WEBPACK_IMPORTED_MODULE_2___default().Header), {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Modal__WEBPACK_IMPORTED_MODULE_2___default().Title), {
                    id: "contained-modal-title-vcenter",
                    children: props.action
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Modal__WEBPACK_IMPORTED_MODULE_2___default().Body), {}),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(MainModalLoader, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(LoaderParent, {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(CircularLoader, {})
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                        children: props.text
                    })
                ]
            })
        ]
    });
};


/***/ }),

/***/ 1129:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "W": () => (/* binding */ verifyToken)
/* harmony export */ });
/* unused harmony export generateNewToken */
/* harmony import */ var jsonwebtoken__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9344);
/* harmony import */ var jsonwebtoken__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(jsonwebtoken__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_1__]);
axios__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


const generateNewToken = async (user)=>{
    const token = jwt.sign({
        username: user.username,
        id: user.id,
        isAdmin: user.isAdmin
    }, process.env.JWT_SECRET_KEY, {
        expiresIn: "8d"
    });
    return token;
};
const verifyToken = async (token)=>{
    try {
        const response = await axios__WEBPACK_IMPORTED_MODULE_1__["default"].get("/api/auth/login", {
            headers: {
                Authorization: `Bearer ${token}`
            }
        });
        return await response.data.user;
    } catch (error) {
        return error;
    }
};


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;