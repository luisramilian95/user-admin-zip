exports.id = 948;
exports.ids = [948];
exports.modules = {

/***/ 9926:
/***/ ((module) => {

// Exports
module.exports = {
	"svg": "svg_svg__tG6pQ"
};


/***/ }),

/***/ 6822:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "H": () => (/* binding */ SvgComponent)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _svg_module_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9926);
/* harmony import */ var _svg_module_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_svg_module_css__WEBPACK_IMPORTED_MODULE_2__);



const SvgComponent = (props)=>{
    const { Svg , className , ...rest } = props;
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
        ...rest,
        src: Svg.src,
        alt: "My SVG",
        className: className || (_svg_module_css__WEBPACK_IMPORTED_MODULE_2___default().svg)
    });
};



/***/ }),

/***/ 973:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "gB": () => (/* binding */ IsActiveStyledCheckBox),
/* harmony export */   "hU": () => (/* binding */ IconButton),
/* harmony export */   "k$": () => (/* binding */ SaveButton),
/* harmony export */   "wg": () => (/* binding */ AdminButton),
/* harmony export */   "yV": () => (/* binding */ LoginAsClientButton)
/* harmony export */ });
/* unused harmony exports LogoutButton, ClientConfigCompositionBtn, ClientConfigVenueBtn, OutputClientBtn */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_1__);


const AdminButton = styled_components__WEBPACK_IMPORTED_MODULE_1___default().button.withConfig({
    componentId: "sc-79a4e6de-0"
})`
  border: 1px solid #047857;
  color: #047857;

  &:hover {
    background-color: #0fa77c !important;
    border: 1px solid #0fa77c !important;
  }
`;
const LoginAsClientButton = styled_components__WEBPACK_IMPORTED_MODULE_1___default().button.withConfig({
    componentId: "sc-79a4e6de-1"
})`
  margin-left: 20px; 

`;
const LogoutButton = styled_components__WEBPACK_IMPORTED_MODULE_1___default().button.withConfig({
    componentId: "sc-79a4e6de-2"
})`
  width: 100%;
  margin-right: 5px;
  background-color: #6c757d;
  color: #ffffff;

  &:hover {
    background-color: #686c70;
    color: #ffffff;
  }
`;
const ClientConfigCompositionBtn = styled_components__WEBPACK_IMPORTED_MODULE_1___default().button.withConfig({
    componentId: "sc-79a4e6de-3"
})`
  height: 100%;
  width: auto;
  flex: 1;
  background-color: ${(props)=>props.isActive ? "#22c55e" : "#16a34a"};
  border: 1px solid #15803d;
  color: white; 
  border-radius: 5px;
  

  &:hover {
    background-color: #15803d;
  }
`;
const ClientConfigVenueBtn = styled_components__WEBPACK_IMPORTED_MODULE_1___default().button.withConfig({
    componentId: "sc-79a4e6de-4"
})`
  height: 100%;
  width: auto;
  flex: 1;
  background-color: ${(props)=>props.isActive ? "#22c55e" : "#16a34a"};
  border: 1px solid #15803d;
  color: white; 
  border-radius: 5px;

  &:hover {
    background-color: #15803d;
  }
`;
const OutputClientBtn = styled_components__WEBPACK_IMPORTED_MODULE_1___default().button.withConfig({
    componentId: "sc-79a4e6de-5"
})`
  height: 100%;
  width: auto;
  flex: 1;
  background-color: ${(props)=>props.isActive ? "#22c55e" : "#16a34a"};
  border: 1px solid #15803d;
  color: white; 
  border-radius: 5px;

  &:hover {
    background-color: #15803d;
  }
`;
const SwitchLabel = styled_components__WEBPACK_IMPORTED_MODULE_1___default().label.withConfig({
    componentId: "sc-79a4e6de-6"
})`
  margin-left: 1px;
`;
const SwitchSlider = styled_components__WEBPACK_IMPORTED_MODULE_1___default().span.withConfig({
    componentId: "sc-79a4e6de-7"
})`
  background-color: #ffffff2b;
  border-radius: 100px;
  padding: 1px;
  margin: 0 0 0 15px;
  cursor: pointer;
  transition: box-shadow 0.2s cubic-bezier(0.4, 0, 0.2, 1) 0s;
  align-items: center;
  position: relative;
  display: inline-block;
  width: 45px;
  height: 24px;
  box-shadow: rgba(0, 0, 0, 0.62) 0px 0px 5px inset,
    rgba(0, 0, 0, 0.21) 0px 0px 0px 24px inset, #22cc3f 0px 0px 0px 0px inset,
    rgba(224, 224, 224, 0.45) 0px 1px 0px 0px;

  &::after {
    content: '';
    display: flex;
    top: 2.3px;
    left: 2px;
    width: 18px;
    height: 18px;
    background-color: #e3e3e3;
    border-radius: 200px;
    position: absolute;
    box-shadow: transparent 0px 0px 0px 2px, rgba(0, 0, 0, 0.3) 0px 6px 6px;
    transition: left 300ms cubic-bezier(0.4, 0, 0.2, 1) 0s,
      background-color 300ms cubic-bezier(0.4, 0, 0.2, 1) 0s;
    will-change: left, background-color;
  }
`;
const SwitchInput = styled_components__WEBPACK_IMPORTED_MODULE_1___default().input.withConfig({
    componentId: "sc-79a4e6de-8"
})`
  display: none;

  &:checked + ${SwitchSlider} {
    /* box-shadow: rgba(0, 0, 0, 0.62) 0px 0px 5px inset,
      #22cc3f 0px 0px 0px 2px inset, #22cc3f 0px 0px 0px 24px inset,
      rgba(224, 224, 224, 0.45) 0px 1px 0px 0px; */
      background-color: #22cc3f;
  }

  &:checked + ${SwitchSlider}::after {
    left: 24px;
  }
`;
const SaveButton = styled_components__WEBPACK_IMPORTED_MODULE_1___default().button.withConfig({
    componentId: "sc-79a4e6de-9"
})`
  width: 100%;
  background-color: #00b862;
  color: #ffffff;
  width: 25%;

  &:hover {
    background-color: #028b4b;
    color: #ffffff;
  }
`;
const IconButton = styled_components__WEBPACK_IMPORTED_MODULE_1___default().button.withConfig({
    componentId: "sc-79a4e6de-10"
})`
  all: unset;
  padding: 4px;
  color: ${(props)=>{
    switch(props.variant){
        case "secondary":
            return "#6c757d";
        case "danger":
            return "#dc3545";
        default:
            return "#0d6efd";
    }
}};
  &:hover {
    color: black; 
  }
`;
const IsActiveStyledCheckBox = (props)=>{
    const { handleToggle , isActive  } = props;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(SwitchLabel, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(SwitchInput, {
                type: "checkbox",
                name: "switchInput",
                checked: isActive,
                onChange: handleToggle
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(SwitchSlider, {})
        ]
    });
};


/***/ })

};
;