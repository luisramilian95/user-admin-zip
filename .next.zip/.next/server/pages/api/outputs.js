"use strict";
(() => {
var exports = {};
exports.id = 653;
exports.ids = [653];
exports.modules = {

/***/ 3524:
/***/ ((module) => {

module.exports = require("@prisma/client");

/***/ }),

/***/ 8054:
/***/ ((module) => {

module.exports = require("bson");

/***/ }),

/***/ 5609:
/***/ ((module) => {

module.exports = require("yup");

/***/ }),

/***/ 1962:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _prisma_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3524);
/* harmony import */ var _prisma_client__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_prisma_client__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5609);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(yup__WEBPACK_IMPORTED_MODULE_1__);

 //Validate data
const prisma = __webpack_require__(998);
const objectIdValidator = __webpack_require__(3528);
async function handler(req, res) {
    const method = req.method;
    let validatedParams;
    let output;
    // Validate params data.
    const schema = yup__WEBPACK_IMPORTED_MODULE_1__.object().shape({
        outputId: objectIdValidator,
        appInstanceId: yup__WEBPACK_IMPORTED_MODULE_1__.number().integer()
    });
    if (req.query.outputId || req.query.appInstanceId) {
        try {
            validatedParams = await schema.validate(req.query);
        } catch (error) {
            return res.status(405).end(`Error with the props provided. ` + error.errors[0]);
        }
    }
    if (!validatedParams) {
        switch(method){
            // List outputs
            case "GET":
                try {
                    const outputs = await prisma.output.findMany();
                    prisma.$disconnect;
                    res.status(200).json(outputs);
                    break;
                } catch (err) {
                    if (err instanceof _prisma_client__WEBPACK_IMPORTED_MODULE_0__.Prisma.PrismaClientKnownRequestError) {
                        res.status(400).json(`${err}`);
                        break;
                    }
                    res.status(400).json(`${err}`);
                    break;
                }
            case "POST":
                // Create output
                let requestData = req.body;
                try {
                    output = await prisma.output.create({
                        data: requestData
                    });
                    prisma.$disconnect;
                    res.status(200).json(output);
                    break;
                } catch (err) {
                    if (err instanceof _prisma_client__WEBPACK_IMPORTED_MODULE_0__.Prisma.PrismaClientKnownRequestError) {
                        if (err.code === "P2002") {
                            res.status(400).json(`Field '${err.meta.target}' already exists and must be unique.`);
                            break;
                        }
                        if (err.code === "P2003") {
                            res.status(400).json(`Foreign key constraint failed on the field: ${err.meta.field_name}`);
                            break;
                        }
                        if (err instanceof _prisma_client__WEBPACK_IMPORTED_MODULE_0__.Prisma.PrismaClientValidationError) {
                            res.status(400).json(`Validation error, Invalid data inserted`);
                            break;
                        }
                    }
                    res.status(400).json({
                        Error: err
                    });
                    break;
                }
            default:
                res.status(405).end(`Method ${method} Not Allowed.`);
                break;
        }
    } else if (validatedParams.outputId) {
        let outputId = validatedParams.outputId;
        switch(method){
            case "GET":
                try {
                    // Retrieve an output by outputId
                    output = await prisma.output.findUnique({
                        where: {
                            id: outputId
                        }
                    });
                    prisma.$disconnect;
                    if (output === null) {
                        res.status(404).json(`The output with outputId '${outputId}' doesn't exists.`);
                        break;
                    }
                    res.status(200).json(output);
                    break;
                } catch (err) {
                    if (err instanceof _prisma_client__WEBPACK_IMPORTED_MODULE_0__.Prisma.PrismaClientKnownRequestError) {
                        res.status(400).json(`${err}`);
                        break;
                    }
                    res.status(400).json(`${err}`);
                    break;
                }
            case "PATCH":
                // Update an output by outputId
                try {
                    let requestData = req.body;
                    output = await prisma.output.update({
                        where: {
                            id: outputId
                        },
                        data: requestData
                    });
                    prisma.$disconnect;
                    res.status(200).json(output);
                    break;
                } catch (err) {
                    if (err instanceof _prisma_client__WEBPACK_IMPORTED_MODULE_0__.Prisma.PrismaClientKnownRequestError) {
                        if (err.code === "P2003") {
                            res.status(400).json(`Foreign key constraint failed on the field: ${err.meta.field_name}`);
                            break;
                        }
                        res.status(404).json(`${err.meta.cause}`);
                        break;
                    }
                    if (err instanceof _prisma_client__WEBPACK_IMPORTED_MODULE_0__.Prisma.PrismaClientValidationError) {
                        res.status(400).json(`Validation error, invalid data inserted.`);
                        break;
                    }
                    res.status(400).json(`${err}`);
                    break;
                }
            case "DELETE":
                // Delete an output by outputId
                try {
                    output = await prisma.output.delete({
                        where: {
                            id: outputId
                        }
                    });
                    prisma.$disconnect;
                    res.status(200).json(`Output ${outputId} deleted successfully.`);
                    break;
                } catch (err) {
                    if (err instanceof _prisma_client__WEBPACK_IMPORTED_MODULE_0__.Prisma.PrismaClientKnownRequestError) {
                        res.status(404).json(`${err.meta.cause}`);
                        break;
                    }
                    res.status(400).json(`${err}`);
                    break;
                }
            default:
                res.status(405).end(`Method ${method} Not Allowed.`);
                break;
        }
    } else if (validatedParams.appInstanceId) {
        let appInstanceId = validatedParams.appInstanceId;
        switch(method){
            case "GET":
                try {
                    // Retrieve an output by appInstanceId
                    output = await prisma.output.findUnique({
                        where: {
                            appInstanceId: appInstanceId
                        }
                    });
                    prisma.$disconnect;
                    if (output === null) {
                        res.status(404).json(`The output with appInstanceId '${appInstanceId}' doesn't exists.`);
                        break;
                    }
                    res.status(200).json(output);
                    break;
                } catch (err) {
                    if (err instanceof _prisma_client__WEBPACK_IMPORTED_MODULE_0__.Prisma.PrismaClientKnownRequestError) {
                        res.status(400).json(`${err}`);
                        break;
                    }
                    res.status(400).json(`${err}`);
                    break;
                }
            case "PATCH":
                // Update an output by appInstanceId
                try {
                    let requestData = req.body;
                    output = await prisma.output.update({
                        where: {
                            appInstanceId: appInstanceId
                        },
                        data: requestData
                    });
                    prisma.$disconnect;
                    res.status(200).json(output);
                    break;
                } catch (err) {
                    if (err instanceof _prisma_client__WEBPACK_IMPORTED_MODULE_0__.Prisma.PrismaClientKnownRequestError) {
                        if (err.code === "P2003") {
                            res.status(400).json(`Foreign key constraint failed on the field: ${err.meta.field_name}`);
                            break;
                        }
                        res.status(404).json(`${err.meta.cause}`);
                        break;
                    }
                    if (err instanceof _prisma_client__WEBPACK_IMPORTED_MODULE_0__.Prisma.PrismaClientValidationError) {
                        res.status(400).json(`Validation error, invalid data inserted.`);
                        break;
                    }
                    res.status(400).json(`${err}`);
                    break;
                }
            case "DELETE":
                // Delete an output by appInstanceId
                try {
                    output = await prisma.output.delete({
                        where: {
                            appInstanceId: appInstanceId
                        }
                    });
                    prisma.$disconnect;
                    res.status(200).json(`appInstanceId ${outappInstanceIdputId} deleted successfully.`);
                    break;
                } catch (err) {
                    if (err instanceof _prisma_client__WEBPACK_IMPORTED_MODULE_0__.Prisma.PrismaClientKnownRequestError) {
                        res.status(404).json(`${err.meta.cause}`);
                        break;
                    }
                    res.status(400).json(`${err}`);
                    break;
                }
            default:
                res.status(405).end(`Method ${method} Not Allowed.`);
                break;
        }
    } else {
        return res.status(405).end(`Error with the props provided.`);
    }
}


/***/ }),

/***/ 3528:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {


const yup = __webpack_require__(5609);
const { ObjectId  } = __webpack_require__(8054);
const objectIdValidator = yup.mixed().test("objectId", "Invalid ObjectID", function(value) {
    if (value === undefined) {
        return true; // Ignorar validación si el valor es undefined
    }
    return ObjectId.isValid(value);
});
module.exports = objectIdValidator;


/***/ }),

/***/ 998:
/***/ ((module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({
    value: true
}));
const _client = __webpack_require__(3524);
// Crear una única instancia de Prisma
const prisma = new _client.PrismaClient();
module.exports = prisma;


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(1962));
module.exports = __webpack_exports__;

})();