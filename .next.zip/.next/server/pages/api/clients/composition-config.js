"use strict";
(() => {
var exports = {};
exports.id = 839;
exports.ids = [839];
exports.modules = {

/***/ 3524:
/***/ ((module) => {

module.exports = require("@prisma/client");

/***/ }),

/***/ 8054:
/***/ ((module) => {

module.exports = require("bson");

/***/ }),

/***/ 5609:
/***/ ((module) => {

module.exports = require("yup");

/***/ }),

/***/ 1704:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _prisma_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3524);
/* harmony import */ var _prisma_client__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_prisma_client__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5609);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(yup__WEBPACK_IMPORTED_MODULE_1__);

 //Validate data
const prisma = __webpack_require__(998);
const objectIdValidator = __webpack_require__(3528);
async function handler(req, res) {
    const method = req.method;
    let validatedParams;
    const requestData = req.body;
    // Validate params data.
    const schema = yup__WEBPACK_IMPORTED_MODULE_1__.object().shape({
        clientId: objectIdValidator.required(),
        compositionId: objectIdValidator.required()
    });
    if (req.query.clientId && req.query.compositionId) {
        try {
            validatedParams = await schema.validate(req.query);
        } catch (error) {
            return res.status(405).end(`Error with the props provided. ` + error.errors[0]);
        }
    }
    if (validatedParams.clientId && validatedParams.compositionId) {
        switch(method){
            case "POST":
                try {
                    const compositionConfig = await prisma.compositionConfig.create({
                        data: {
                            ...requestData,
                            clientId: validatedParams.clientId,
                            compositionId: validatedParams.compositionId
                        }
                    });
                    prisma.$disconnect;
                    res.status(201).json(compositionConfig);
                    break;
                } catch (err) {
                    if (err instanceof _prisma_client__WEBPACK_IMPORTED_MODULE_0__.Prisma.PrismaClientKnownRequestError) {
                        if (err.code === "P2002") {
                            res.status(400).json(`Field '${err.meta.target}' already exists and must be unique.`);
                            break;
                        }
                        if (err instanceof _prisma_client__WEBPACK_IMPORTED_MODULE_0__.Prisma.PrismaClientValidationError) {
                            res.status(400).json(`Validation error, invalid data inserted.`);
                            break;
                        }
                    }
                    res.status(400).json(`${err}`);
                    break;
                }
            case "PATCH":
                try {
                    const compositionConfig = await prisma.compositionConfig.updateMany({
                        where: {
                            clientId: validatedParams.clientId,
                            compositionId: validatedParams.compositionId
                        },
                        data: {
                            ...requestData,
                            clientId: validatedParams.clientId,
                            compositionId: validatedParams.compositionId
                        }
                    });
                    prisma.$disconnect;
                    res.status(200).json(compositionConfig);
                    break;
                } catch (err) {
                    if (err instanceof _prisma_client__WEBPACK_IMPORTED_MODULE_0__.Prisma.PrismaClientKnownRequestError) {
                        res.status(404).json(`${err.meta.cause}`);
                        break;
                    }
                    if (err instanceof _prisma_client__WEBPACK_IMPORTED_MODULE_0__.Prisma.PrismaClientValidationError) {
                        res.status(400).json(`Validation error, invalid data inserted.`);
                        break;
                    }
                    res.status(400).json(`${err}`);
                    break;
                }
            case "DELETE":
                try {
                    const compositionConfig = await prisma.compositionConfig.deleteMany({
                        where: {
                            clientId: validatedParams.clientId,
                            compositionId: validatedParams.compositionId
                        }
                    });
                    prisma.$disconnect;
                    res.status(200).json(`Composition Config: ${validatedParams.clientId} ${validatedParams.compositionId} deleted successfully.`);
                    break;
                } catch (err) {
                    if (err instanceof _prisma_client__WEBPACK_IMPORTED_MODULE_0__.Prisma.PrismaClientKnownRequestError) {
                        res.status(404).json(`${err.meta.cause}`);
                        break;
                    }
                    res.status(400).json(`${err}`);
                    break;
                }
            default:
                res.status(405).end(`Method ${method} Not Allowed.`);
                break;
        }
    } else {
        return res.status(405).end(`Error with the props provided.`);
    }
}


/***/ }),

/***/ 3528:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {


const yup = __webpack_require__(5609);
const { ObjectId  } = __webpack_require__(8054);
const objectIdValidator = yup.mixed().test("objectId", "Invalid ObjectID", function(value) {
    if (value === undefined) {
        return true; // Ignorar validación si el valor es undefined
    }
    return ObjectId.isValid(value);
});
module.exports = objectIdValidator;


/***/ }),

/***/ 998:
/***/ ((module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({
    value: true
}));
const _client = __webpack_require__(3524);
// Crear una única instancia de Prisma
const prisma = new _client.PrismaClient();
module.exports = prisma;


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(1704));
module.exports = __webpack_exports__;

})();