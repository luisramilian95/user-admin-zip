"use strict";
(() => {
var exports = {};
exports.id = 860;
exports.ids = [860];
exports.modules = {

/***/ 3524:
/***/ ((module) => {

module.exports = require("@prisma/client");

/***/ }),

/***/ 7695:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
const prisma = __webpack_require__(998);
/**
 * The handler will be in charge of returning all the needed data to the client first load.
 *
 * - Compositions
 * - Venues
 */ async function handler(req, res) {
    const { clientId  } = req.query;
    const { method  } = req;
    switch(method){
        case "GET":
            {
                const compositions = await prisma.compositionConfig.findMany({
                    where: {
                        clientId,
                        isActive: true
                    },
                    include: {
                        composition: true
                    }
                });
                const { assignedVenues  } = await prisma.client.findUnique({
                    select: {
                        assignedVenues: {
                            select: {
                                externalId: true,
                                name: true,
                                localProvider: true,
                                codeType: true,
                                settings: true
                            }
                        }
                    },
                    where: {
                        id: clientId
                    }
                });
                res.status(200).json({
                    compositions,
                    assignedVenues
                });
            }
    }
}


/***/ }),

/***/ 998:
/***/ ((module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({
    value: true
}));
const _client = __webpack_require__(3524);
// Crear una única instancia de Prisma
const prisma = new _client.PrismaClient();
module.exports = prisma;


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(7695));
module.exports = __webpack_exports__;

})();