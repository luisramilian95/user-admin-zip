"use strict";
(() => {
var exports = {};
exports.id = 305;
exports.ids = [305];
exports.modules = {

/***/ 3524:
/***/ ((module) => {

module.exports = require("@prisma/client");

/***/ }),

/***/ 7096:
/***/ ((module) => {

module.exports = require("bcrypt");

/***/ }),

/***/ 5609:
/***/ ((module) => {

module.exports = require("yup");

/***/ }),

/***/ 5109:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _prisma_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3524);
/* harmony import */ var _prisma_client__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_prisma_client__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5609);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(yup__WEBPACK_IMPORTED_MODULE_1__);

 //Validate data
const bcrypt = __webpack_require__(7096);
const prisma = __webpack_require__(998);
async function handler(req, res) {
    const method = req.method;
    let validatedParams;
    let user;
    // Validate params data.
    const schema = yup__WEBPACK_IMPORTED_MODULE_1__.object().shape({
        username: yup__WEBPACK_IMPORTED_MODULE_1__.string(),
        isAdmin: yup__WEBPACK_IMPORTED_MODULE_1__.boolean()
    });
    if (req.query.username || req.query.isAdmin) {
        try {
            validatedParams = await schema.validate(req.query);
        } catch (error) {
            return res.status(405).end(`Error with the props provided. ` + error.errors[0]);
        }
    }
    if (!validatedParams) {
        switch(method){
            case "GET":
                try {
                    const users = await prisma.user.findMany({
                        select: {
                            // Select the data that will be displayed by the object
                            id: true,
                            username: true,
                            isAdmin: true,
                            isActive: true,
                            clientId: true,
                            createdAt: true,
                            lastLogin: true
                        }
                    });
                    prisma.$disconnect;
                    res.status(200).json(users);
                    break;
                } catch (err) {
                    if (err instanceof _prisma_client__WEBPACK_IMPORTED_MODULE_0__.Prisma.PrismaClientKnownRequestError) {
                        res.status(400).json(`${err}`);
                        break;
                    }
                    res.status(400).json(`${err}`);
                    break;
                }
            case "POST":
                let requestData = req.body;
                const password = requestData["password"];
                const passwordConfirmation = requestData["passwordConfirmation"];
                if (password != passwordConfirmation) {
                    res.status(400).json("Passwords doesn't match.");
                    break;
                }
                try {
                    const hashPassword = await bcrypt.hash(password, 10);
                    delete requestData.passwordConfirmation;
                    requestData.password = hashPassword;
                    user = await prisma.user.create({
                        data: requestData
                    });
                    prisma.$disconnect;
                    delete user.password;
                    res.status(200).json(user);
                    break;
                } catch (err) {
                    if (err instanceof _prisma_client__WEBPACK_IMPORTED_MODULE_0__.Prisma.PrismaClientKnownRequestError) {
                        if (err.code === "P2002") {
                            res.status(400).json(`Field '${err.meta.target}' already exists and must be unique.`);
                            break;
                        }
                        if (err.code === "P2003") {
                            res.status(400).json(`Foreign key constraint failed on the field: ${err.meta.field_name}`);
                            break;
                        }
                        if (err instanceof _prisma_client__WEBPACK_IMPORTED_MODULE_0__.Prisma.PrismaClientValidationError) {
                            res.status(400).json(`Validation error, Invalid data inserted`);
                            break;
                        }
                    }
                    res.status(400).json({
                        Error: err
                    });
                    break;
                }
            default:
                res.status(405).end(`Method ${method} Not Allowed.`);
                break;
        }
    } else if (validatedParams.username && !validatedParams.isAdmin) {
        let userUsername = validatedParams.username;
        switch(method){
            case "GET":
                try {
                    // Retrieve an user by username
                    user = await prisma.user.findUnique({
                        where: {
                            username: userUsername
                        },
                        select: {
                            //  Select the data that will be displayed by the object
                            id: true,
                            username: true,
                            isAdmin: true,
                            isActive: true,
                            clientId: true,
                            createdAt: true,
                            lastLogin: true
                        }
                    });
                    prisma.$disconnect;
                    if (user === null) {
                        res.status(404).json(`The user with username '${userUsername}' doesn't exists.`);
                        break;
                    }
                    res.status(200).json(user);
                    break;
                } catch (err) {
                    if (err instanceof _prisma_client__WEBPACK_IMPORTED_MODULE_0__.Prisma.PrismaClientKnownRequestError) {
                        res.status(400).json(`${err}`);
                        break;
                    }
                    res.status(400).json(`${err}`);
                    break;
                }
            case "PATCH":
                // Update an user by username
                try {
                    let requestData = req.body;
                    if (requestData.password) {
                        const hashPassword = await bcrypt.hash(requestData.password, 10);
                        requestData.password = hashPassword;
                    }
                    user = await prisma.user.update({
                        where: {
                            username: userUsername
                        },
                        data: requestData,
                        select: {
                            // Select the data that will be displayed by the object
                            id: true,
                            username: true,
                            isAdmin: true,
                            isActive: true,
                            clientId: true,
                            createdAt: true,
                            lastLogin: true
                        }
                    });
                    prisma.$disconnect;
                    res.status(200).json(user);
                    break;
                } catch (err) {
                    if (err instanceof _prisma_client__WEBPACK_IMPORTED_MODULE_0__.Prisma.PrismaClientKnownRequestError) {
                        if (err.code === "P2002") {
                            res.status(400).json(`Field '${err.meta.target}' already exists and must be unique.`);
                            break;
                        }
                        if (err.code === "P2003") {
                            res.status(400).json(`Foreign key constraint failed on the field: ${err.meta.field_name}`);
                            break;
                        }
                    }
                    if (err instanceof _prisma_client__WEBPACK_IMPORTED_MODULE_0__.Prisma.PrismaClientValidationError) {
                        res.status(400).json(`Validation error, invalid data inserted.`);
                        break;
                    }
                    res.status(400).json(`${err}`);
                    break;
                }
            case "DELETE":
                // Delete an user by username
                try {
                    user = await prisma.user.delete({
                        where: {
                            username: userUsername
                        }
                    });
                    prisma.$disconnect;
                    res.status(200).json(`User ${userUsername} deleted successfully.`);
                    break;
                } catch (err) {
                    if (err instanceof _prisma_client__WEBPACK_IMPORTED_MODULE_0__.Prisma.PrismaClientKnownRequestError) {
                        res.status(404).json(`${err.meta.cause}`);
                        break;
                    }
                    res.status(400).json(`${err}`);
                    break;
                }
            default:
                res.status(405).end(`Method ${method} Not Allowed.`);
                break;
        }
    } else if (validatedParams.isAdmin) {
        switch(method){
            case "GET":
                try {
                    const users = await prisma.user.findMany({
                        where: {
                            isAdmin: true
                        },
                        select: {
                            // Select the data that will be displayed by the object
                            id: true,
                            username: true,
                            isAdmin: true,
                            isActive: true,
                            clientId: true,
                            createdAt: true,
                            lastLogin: true
                        }
                    });
                    prisma.$disconnect;
                    res.status(200).json(users);
                    break;
                } catch (err) {
                    if (err instanceof _prisma_client__WEBPACK_IMPORTED_MODULE_0__.Prisma.PrismaClientKnownRequestError) {
                        res.status(400).json(`${err}`);
                        break;
                    }
                    res.status(400).json(`${err}`);
                    break;
                }
        }
    } else {
        return res.status(405).end(`Error with the props provided.`);
    }
}


/***/ }),

/***/ 998:
/***/ ((module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({
    value: true
}));
const _client = __webpack_require__(3524);
// Crear una única instancia de Prisma
const prisma = new _client.PrismaClient();
module.exports = prisma;


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(5109));
module.exports = __webpack_exports__;

})();