"use strict";
(() => {
var exports = {};
exports.id = 908;
exports.ids = [908];
exports.modules = {

/***/ 3524:
/***/ ((module) => {

module.exports = require("@prisma/client");

/***/ }),

/***/ 7096:
/***/ ((module) => {

module.exports = require("bcrypt");

/***/ }),

/***/ 9344:
/***/ ((module) => {

module.exports = require("jsonwebtoken");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 6449:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _services_fetchAdminData__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6919);
/* harmony import */ var _prisma_client__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3524);
/* harmony import */ var _prisma_client__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_prisma_client__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _utils_JWTAuth__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(511);
/* harmony import */ var jsonwebtoken__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9344);
/* harmony import */ var jsonwebtoken__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(jsonwebtoken__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_services_fetchAdminData__WEBPACK_IMPORTED_MODULE_0__, _utils_JWTAuth__WEBPACK_IMPORTED_MODULE_2__]);
([_services_fetchAdminData__WEBPACK_IMPORTED_MODULE_0__, _utils_JWTAuth__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




const bcrypt = __webpack_require__(7096);
const prisma = __webpack_require__(998);
async function handler(req, res) {
    const method = req.method;
    switch(method){
        case "POST":
            try {
                const { username , password  } = req.body;
                // Retrieve an user by username
                const user = await prisma.user.findUnique({
                    where: {
                        username: username
                    }
                });
                prisma.$disconnect;
                if (user === null) {
                    res.status(404).json(`The user with username '${username}' doesn't exists.`);
                    break;
                }
                // Compare the password
                const match = await bcrypt.compare(password, user.password);
                if (match) {
                    // Create a token
                    const token = await (0,_utils_JWTAuth__WEBPACK_IMPORTED_MODULE_2__/* .generateNewToken */ .g)(user);
                    return res.status(200).json({
                        message: "Login successful",
                        status_code: 200,
                        accessToken: token
                    });
                } else {
                    res.status(401).json("Invalid credentials.");
                    break;
                }
            } catch (err) {
                prisma.$disconnect;
                if (err instanceof _prisma_client__WEBPACK_IMPORTED_MODULE_1__.Prisma.PrismaClientKnownRequestError) {
                    res.status(400).json(`${err}`);
                    break;
                }
                res.status(400).json(`${err}`);
                break;
            }
        case "GET":
            const token = req.headers.authorization?.split(" ")[1];
            if (!token) {
                return res.status(401).json({
                    message: "The authentication token was not provided."
                });
            }
            jsonwebtoken__WEBPACK_IMPORTED_MODULE_3___default().verify(token, process.env.JWT_SECRET_KEY, (err, decoded)=>{
                if (err) {
                    return res.status(403).json({
                        message: "Invalid or expired token."
                    });
                }
                res.status(200).json({
                    user: decoded
                });
            });
            break;
    }
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6919:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* unused harmony exports getData, postData, deleteData, updateData, getClients, retrieveClient, getAdminClients, createClient, deleteClient, updateClient, createClientCompositionConfig, updateClientCompositionConfig, deleteClientCompositionConfig, getAdminUsers, createUser, deleteUser, updateUser, retrieveUser, loginUser, getCompositions, createComposition, UpdateComposition, deleteComposition, getVenues, createVenue, updateVenue, getApiVenues, getApiVenueInfo, getSubcompositions, createSubComposition, getSingularToken, refreshSingularToken, duplicateAppInstance, updateAppInstance, deleteAppInstance, createDataStream, updateDataStream, deleteDataStream, createOutput, updateOutput, deleteOutput */
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const api = axios__WEBPACK_IMPORTED_MODULE_0__["default"].create({
    headers: {
        "Content-Type": "application/json"
    }
});
const getData = async (params)=>{
    try {
        const response = await api.get(params);
        return response.data;
    } catch (error) {
        return error;
    }
};
const postData = async (params, body = {}, accessToken)=>{
    try {
        const response = await api.post(params, body, {
            headers: {
                Authorization: `Bearer ${accessToken}`
            }
        });
        return response.data;
    } catch (error) {
        console.log({
            error
        });
        return error;
    }
};
const deleteData = async (params, accessToken)=>{
    try {
        const response = await api.delete(params, {
            headers: {
                Authorization: `Bearer ${accessToken}`
            }
        });
        return response.data;
    } catch (error) {
        return error;
    }
};
const updateData = async (params, body, accessToken)=>{
    try {
        const response = await api.patch(params, body, {
            headers: {
                Authorization: `Bearer ${accessToken}`
            }
        });
        return response.data;
    } catch (error) {
        return error;
    }
};
// Clients
const getClients = async ()=>{
    let params = `/api/clients`;
    return await getData(params);
};
// Retrieve client
const retrieveClient = async (clientId)=>{
    let params = `/api/clients?clientId=${clientId}`;
    return await getData(params);
};
// Get Admin Client
const getAdminClients = async ()=>{
    let params = `/api/clients?isAdminClient=${true}`;
    return await getData(params);
};
// Create Client
const createClient = async (body, accessToken)=>{
    let params = `/api/clients`;
    return await postData(params, body, accessToken);
};
// Delete client
const deleteClient = async (clientId, accessToken)=>{
    let params = `/api/clients?clientId=${clientId}`;
    return await deleteData(params, accessToken);
};
// Update client
const updateClient = async (clientId, body, accessToken)=>{
    const params = `/api/clients?clientId=${clientId}`;
    return await updateData(params, body, accessToken);
};
// Create client composition related with client
const createClientCompositionConfig = async (clientId, compositionId, body, accessToken)=>{
    let params = `/api/clients/composition-config?clientId=${clientId}&compositionId=${compositionId}`;
    return await postData(params, body, accessToken);
};
// Update client composition related with client
const updateClientCompositionConfig = async (clientId, compositionId, body, accessToken)=>{
    let params = `/api/clients/composition-config?clientId=${clientId}&compositionId=${compositionId}`;
    return await updateData(params, body, accessToken);
};
// Delete client composition related with client
const deleteClientCompositionConfig = async (clientId, compositionId)=>{
    let params = `/api/clients/composition-config?clientId=${clientId}&compositionId=${compositionId}`;
    return await deleteData(params);
};
// Get admin users
const getAdminUsers = async ()=>{
    const params = `/api/auth/users/?isAdmin=true`;
    return await getData(params);
};
// Create user
const createUser = async (body, accessToken)=>{
    // to create a client user body needs clientId
    const params = `/api/auth/users`;
    return await postData(params, body, accessToken);
};
// Delete user
const deleteUser = async (username, accessToken)=>{
    const params = `/api/auth/users?username=${username}`;
    return await deleteData(params, accessToken);
};
// Update user
const updateUser = async (username, body, accessToken)=>{
    const params = `/api/auth/users?username=${username}`;
    return await updateData(params, body, accessToken);
};
// Retrieve user
const retrieveUser = async (username)=>{
    const params = `/api/auth/users?username=${username}`;
    return await getData(params);
};
// Login user
const loginUser = async (body)=>{
    const params = `/api/auth/login`;
    return await postData(params, body);
};
// Get compositions
const getCompositions = async ()=>{
    let params = `/api/compositions`;
    return await getData(params);
};
// Create Composition
const createComposition = async (body, accessToken)=>{
    let params = `/api/compositions`;
    return await postData(params, body, accessToken);
};
// Update composition
const UpdateComposition = async (compositionId, body, accessToken)=>{
    const params = `/api/compositions?compositionId=${compositionId}`;
    return updateData(params, body, accessToken);
};
// Delete composition
const deleteComposition = async (compositionId, accessToken)=>{
    const params = `/api/compositions?compositionId=${compositionId}`;
    return deleteData(params, accessToken);
};
// Get list of Venues
const getVenues = async ()=>{
    let params = `/api/venues`;
    return await getData(params);
};
//Create Venue
const createVenue = async (body, accessToken)=>{
    let params = `/api/venues`;
    return await postData(params, body, accessToken);
};
// Update Venue
const updateVenue = async (venueId, body, accessToken)=>{
    let params = `/api/venues?venueId=${venueId}`;
    return await updateData(params, body, accessToken);
};
// Get Api venues
let apiKey = "KcqNYhGtIh8r7cj7kIMys3YJIfGiCvmr7dTuUPuH";
const getApiVenues = async ()=>{
    let url = "https://hy8ix63kw2.execute-api.ap-southeast-2.amazonaws.com/Dev/getvenues";
    let res = await axios.get(url, {
        headers: {
            "x-api-key": apiKey
        }
    });
    return res.data;
};
// Get Api venues Information
const getApiVenueInfo = async (externalVenueId)=>{
    let url = `https://hy8ix63kw2.execute-api.ap-southeast-2.amazonaws.com/Dev/getvenue?ExternalVenueId=${externalVenueId}`;
    let res = await axios.get(url, {
        headers: {
            "x-api-key": apiKey
        }
    });
    return res.data;
};
// get SubCompositions
const getSubcompositions = async ()=>{
    let params = `/api/subcompositions`;
    return await getData(params);
};
// Create SubComposition
const createSubComposition = async (body, accessToken)=>{
    let params = `/api/subcompositions`;
    return await postData(params, body, accessToken);
};
const getSingularToken = async ()=>{
    const url = `https://app.singular.live/apiv2/users/logintoken`;
    const body = {
        email: "lesliekajomovitz@gmail.com",
        password: "cybulalau26"
    };
    try {
        const res = await axios.post(url, body);
        return res.data;
    } catch (error) {
        console.log(error);
        return error;
    }
};
const refreshSingularToken = async (refreshToken)=>{
    const url = `https://app.singular.live/apiv2/users/refreshtoken`;
    let body = {
        refreshToken: refreshToken
    };
    try {
        const res = await axios.post(url, body);
        return res.data;
    } catch (error) {
        return error;
    }
};
// Duplicate singular app instance
const duplicateAppInstance = async (appInstanceId, body, singularToken)=>{
    const url = `https://app.singular.live/apiv2/controlapps/${appInstanceId}/duplicate`;
    try {
        const res = await axios.post(url, body, {
            headers: {
                Authorization: `Bearer ${singularToken}`
            }
        });
        return res.data;
    } catch (error) {
        return error;
    }
};
// update AppInstance
const updateAppInstance = async (appInstanceId, body, singularToken)=>{
    const url = `https://app.singular.live/apiv2/controlapps/${appInstanceId}`;
    try {
        const res = await axios.patch(url, body, {
            headers: {
                Authorization: `Bearer ${singularToken}`
            }
        });
        return res.data;
    } catch (error) {
        console.log(error);
        return error;
    }
};
// Delete AppInstance
const deleteAppInstance = async (appInstanceId, singularToken)=>{
    const url = `https://app.singular.live/apiv2/controlapps/${appInstanceId}`;
    try {
        const res = await axios.delete(url, {
            headers: {
                Authorization: `Bearer ${singularToken}`
            }
        });
        return res.data;
    } catch (error) {
        console.log(error);
        return error;
    }
};
const headers = {
    Authorization: `Basic ${Buffer.from(`${"lesliekajomovitz@gmail.com"}:${"cybulalau26"}`).toString("base64")}`
};
// Create Datastream
const createDataStream = async (body)=>{
    const url = `https://app.singular.live/apiv1/datastreams`;
    try {
        const res = await axios.post(url, body, {
            headers
        });
        return res.data;
    } catch (error) {
        return error;
    }
};
// Update Datastream
const updateDataStream = async (datastreamId, body)=>{
    const url = `https://app.singular.live/apiv1/datastreams/${datastreamId}`;
    try {
        const res = await axios.put(url, body, {
            headers
        });
        return res.data;
    } catch (error) {
        console.log(error);
        return error;
    }
};
// Delete Datastream
const deleteDataStream = async (datastreamId)=>{
    const url = `https://app.singular.live/apiv1/datastreams/${datastreamId}`;
    try {
        const res = await axios.delete(url, {
            headers
        });
        return res.data;
    } catch (error) {
        return error;
    }
};
// Create Output
const createOutput = async (body, accessToken)=>{
    let params = `/api/outputs`;
    return await postData(params, body, accessToken);
};
// Update Output
const updateOutput = async (outputId, body, accessToken)=>{
    let params = `/api/outputs?outputId=${outputId}`;
    return await updateData(params, body, accessToken);
};
// Delete Output
const deleteOutput = async (outputId, accessToken)=>{
    let params = `/api/outputs?outputId=${outputId}`;
    return await deleteData(params, accessToken);
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 511:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "g": () => (/* binding */ generateNewToken)
/* harmony export */ });
/* unused harmony export verifyToken */
/* harmony import */ var jsonwebtoken__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9344);
/* harmony import */ var jsonwebtoken__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(jsonwebtoken__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_1__]);
axios__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


const generateNewToken = async (user)=>{
    const token = jsonwebtoken__WEBPACK_IMPORTED_MODULE_0___default().sign({
        username: user.username,
        id: user.id,
        isAdmin: user.isAdmin
    }, process.env.JWT_SECRET_KEY, {
        expiresIn: "8d"
    });
    return token;
};
const verifyToken = async (token)=>{
    try {
        const response = await axios.get("/api/auth/login", {
            headers: {
                Authorization: `Bearer ${token}`
            }
        });
        return await response.data.user;
    } catch (error) {
        return error;
    }
};


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 998:
/***/ ((module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({
    value: true
}));
const _client = __webpack_require__(3524);
// Crear una única instancia de Prisma
const prisma = new _client.PrismaClient();
module.exports = prisma;


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(6449));
module.exports = __webpack_exports__;

})();