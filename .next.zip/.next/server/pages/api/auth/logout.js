(() => {
var exports = {};
exports.id = 845;
exports.ids = [845];
exports.modules = {

/***/ 301:
/***/ (() => {

// import { serialize } from 'cookie';
// export default function logoutHandler(req, res) {
//   const { userToken } = req.cookies;
//   if (!userToken) {
//     return res.status(401).json({ error: 'Not logged in' });
//   }
//   const serialized = serialize('userToken', null, {
//     httpOnly: true,
//     secure: process.env.NODE_ENV === 'production',
//     sameSite: 'strict',
//     maxAge: 0,
//     path: '/',
//   });
//   res.setHeader('Set-Cookie', serialized);
//   return res.status(200).json({
//     message: 'Logout successful',
//   });
// }


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(301));
module.exports = __webpack_exports__;

})();