(() => {
var exports = {};
exports.id = 134;
exports.ids = [134];
exports.modules = {

/***/ 1764:
/***/ ((module) => {

// Exports
module.exports = {
	"ListItemsContainer": "ListItems_ListItemsContainer__6WeOl"
};


/***/ }),

/***/ 1444:
/***/ ((module) => {

// Exports
module.exports = {
	"ClientOutputSection": "client-outputs_ClientOutputSection__VtmPz",
	"ClientOutputsList": "client-outputs_ClientOutputsList__mBlW4",
	"ClientOutputsItem": "client-outputs_ClientOutputsItem__DcGHr",
	"ClientOutputsItemNoFound": "client-outputs_ClientOutputsItemNoFound__tuyyQ"
};


/***/ }),

/***/ 8533:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "x": () => (/* binding */ ListItems)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _ListItems_module_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1764);
/* harmony import */ var _ListItems_module_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_ListItems_module_css__WEBPACK_IMPORTED_MODULE_2__);



function ListItems(props) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
        className: `list-group ${(_ListItems_module_css__WEBPACK_IMPORTED_MODULE_2___default().ListItemsContainer)}`,
        children: props.children
    });
}



/***/ }),

/***/ 8521:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ ClientOutput),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_Reusable_styledComponents_loaders__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7309);
/* harmony import */ var next__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3160);
/* harmony import */ var next__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _utils_JWTAuth__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1129);
/* harmony import */ var _context_authContext__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1801);
/* harmony import */ var _services_fetchAdminData__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6664);
/* harmony import */ var _components_Reusable_ListItems_ListItems__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8533);
/* harmony import */ var _client_outputs_module_css__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1444);
/* harmony import */ var _client_outputs_module_css__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_client_outputs_module_css__WEBPACK_IMPORTED_MODULE_9__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils_JWTAuth__WEBPACK_IMPORTED_MODULE_5__, _context_authContext__WEBPACK_IMPORTED_MODULE_6__, _services_fetchAdminData__WEBPACK_IMPORTED_MODULE_7__]);
([_utils_JWTAuth__WEBPACK_IMPORTED_MODULE_5__, _context_authContext__WEBPACK_IMPORTED_MODULE_6__, _services_fetchAdminData__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);










async function getServerSideProps(context) {
    const { query  } = context;
    return {
        props: {
            query
        }
    };
}
function ClientOutput(props) {
    const { accessToken , getAccessToken , setAccessToken  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_authContext__WEBPACK_IMPORTED_MODULE_6__/* .AuthContext */ .V);
    const [client, setClient] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({});
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(true);
    const { query  } = props;
    const clientId = query.clientId;
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_4__.useRouter)();
    const handleOpenControlApp = (output, clientId)=>{
        // open a iframe app instance with the control app
        router.push({
            pathname: `/client-outputs/control-app`,
            query: {
                clientId: clientId,
                url: output.publicControlUrl,
                appInstanceId: output.appInstanceId,
                dataStreamPrivateToken: output.dataStreamPrivateToken,
                dataStreamPublicToken: output.dataStreamPublicToken,
                outputUrl: output.outputUrl
            }
        });
    };
    const userUnauthorizedRedirect = async (route, setAccessToken)=>{
        setAccessToken(null);
        router.push(route);
        return;
    };
    const verifyTokenAndRedirect = async (token, clientId)=>{
        console.log(clientId);
        console.log({
            query
        });
        if (token) {
            const verifiedToken = await (0,_utils_JWTAuth__WEBPACK_IMPORTED_MODULE_5__/* .verifyToken */ .W)(token);
            if (verifiedToken) {
                if (verifiedToken?.name === "AxiosError") {
                    userUnauthorizedRedirect("/login-client", setAccessToken);
                    return;
                }
                let client;
                const user = await (0,_services_fetchAdminData__WEBPACK_IMPORTED_MODULE_7__/* .retrieveUser */ .sJ)(verifiedToken.username);
                if (!clientId) {
                    client = await (0,_services_fetchAdminData__WEBPACK_IMPORTED_MODULE_7__/* .retrieveClient */ .nq)(user.clientId);
                } else {
                    client = await (0,_services_fetchAdminData__WEBPACK_IMPORTED_MODULE_7__/* .retrieveClient */ .nq)(clientId);
                }
                setClient(client);
                if (client && client.outputs && client.outputs.length === 1) {
                    router.push({
                        pathname: `/client-outputs/control-app`,
                        query: {
                            clientId: client.id,
                            url: client.outputs[0].publicControlUrl,
                            appInstanceId: client.outputs[0].appInstanceId,
                            dataStreamPrivateToken: client.outputs[0].dataStreamPrivateToken,
                            dataStreamPublicToken: client.outputs[0].dataStreamPublicToken,
                            outputUrl: client.outputs[0].outputUrl
                        }
                    });
                    setLoading(false);
                }
            } else if (!verifiedToken) {
                userUnauthorizedRedirect("/login-client", setAccessToken);
                return;
            }
        } else {
            userUnauthorizedRedirect("/login-client", setAccessToken);
            return;
        }
        setLoading(false);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        //setLoading(true);
        const token = getAccessToken();
        verifyTokenAndRedirect(token, clientId);
    }, [
        accessToken
    ]);
    if (loading) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Reusable_styledComponents_loaders__WEBPACK_IMPORTED_MODULE_2__/* .MainAppLoader */ .JT, {
            text: "Loading Outputs..."
        });
    } else {
        if (client.outputs.length === 1) {
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Reusable_styledComponents_loaders__WEBPACK_IMPORTED_MODULE_2__/* .MainAppLoader */ .JT, {
                text: "Loading Outputs..."
            });
        }
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
            id: "control-app",
            className: `${(_client_outputs_module_css__WEBPACK_IMPORTED_MODULE_9___default().ClientOutputSection)}`,
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: `${(_client_outputs_module_css__WEBPACK_IMPORTED_MODULE_9___default().ClientOutputsList)}`,
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_Reusable_ListItems_ListItems__WEBPACK_IMPORTED_MODULE_8__/* .ListItems */ .x, {
                    children: [
                        client.outputs && client.outputs.length === 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                            className: `${(_client_outputs_module_css__WEBPACK_IMPORTED_MODULE_9___default().ClientOutputsItemNoFound)}`,
                            children: "No Outputs Found"
                        }),
                        client.outputs && client.outputs.map((output)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                className: `${(_client_outputs_module_css__WEBPACK_IMPORTED_MODULE_9___default().ClientOutputsItem)}`,
                                onClick: ()=>handleOpenControlApp(output, output.clientId),
                                children: output.appInstanceName
                            }, output.id))
                    ]
                })
            })
        })
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9344:
/***/ ((module) => {

"use strict";
module.exports = require("jsonwebtoken");

/***/ }),

/***/ 3160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/lib/import-next-warning");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 9306:
/***/ ((module) => {

"use strict";
module.exports = require("react-bootstrap/Modal");

/***/ }),

/***/ 7518:
/***/ ((module) => {

"use strict";
module.exports = require("styled-components");

/***/ }),

/***/ 9648:
/***/ ((module) => {

"use strict";
module.exports = import("axios");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [893,801,872], () => (__webpack_exec__(8521)));
module.exports = __webpack_exports__;

})();