(() => {
var exports = {};
exports.id = 614;
exports.ids = [614];
exports.modules = {

/***/ 9852:
/***/ ((module) => {

// Exports
module.exports = {
	"ClientControlAppSection": "control-app_ClientControlAppSection__nnhQT",
	"ControlAppIframe": "control-app_ControlAppIframe__sitXA"
};


/***/ }),

/***/ 4363:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _context_authContext__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1801);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _control_app_module_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9852);
/* harmony import */ var _control_app_module_css__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_control_app_module_css__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _utils_JWTAuth__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1129);
/* harmony import */ var _components_Reusable_styledComponents_loaders__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7309);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_context_authContext__WEBPACK_IMPORTED_MODULE_2__, _utils_JWTAuth__WEBPACK_IMPORTED_MODULE_4__]);
([_context_authContext__WEBPACK_IMPORTED_MODULE_2__, _utils_JWTAuth__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







async function getServerSideProps(context) {
    const { query  } = context;
    return {
        props: {
            query
        }
    };
}
function ControlApp(props) {
    const { accessToken , getAccessToken , setAccessToken  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_authContext__WEBPACK_IMPORTED_MODULE_2__/* .AuthContext */ .V);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { query  } = props;
    const clientId = query.clientId;
    const appInstanceId = query.appInstanceId;
    const dataStreamPublicToken = query.dataStreamPublicToken;
    const dataStreamPrivateToken = query.dataStreamPrivateToken;
    const params = `clientId=${clientId}&appInstanceId=${appInstanceId}&dataStreamPrivateToken=${dataStreamPrivateToken}&dataStreamPublicToken=${dataStreamPublicToken}&noHeader=true`;
    const url = query.url;
    const userUnauthorizedRedirect = async (route, setAccessToken)=>{
        setAccessToken(null);
        router.push(route);
        return;
    };
    const verifyTokenAndRedirect = async (token)=>{
        if (token) {
            const verifiedToken = await (0,_utils_JWTAuth__WEBPACK_IMPORTED_MODULE_4__/* .verifyToken */ .W)(token);
            if (verifiedToken) {
                if (verifiedToken?.name === "AxiosError") {
                    userUnauthorizedRedirect("/login-client", setAccessToken);
                    return;
                }
            } else if (!verifiedToken) {
                userUnauthorizedRedirect("/login-client", setAccessToken);
                return;
            }
        } else {
            userUnauthorizedRedirect("/login-client", setAccessToken);
            return;
        }
        setLoading(false);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        setLoading(true);
        const token = getAccessToken();
        verifyTokenAndRedirect(token);
    }, [
        accessToken
    ]);
    if (loading) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Reusable_styledComponents_loaders__WEBPACK_IMPORTED_MODULE_5__/* .MainAppLoader */ .JT, {
            text: "Loading App Instance..."
        });
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
        id: "control-app",
        className: `${(_control_app_module_css__WEBPACK_IMPORTED_MODULE_6___default().ClientControlAppSection)}`,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("iframe", {
            src: `${url}?${params}`,
            className: `${(_control_app_module_css__WEBPACK_IMPORTED_MODULE_6___default().ControlAppIframe)}`
        })
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ControlApp);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9344:
/***/ ((module) => {

"use strict";
module.exports = require("jsonwebtoken");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 9306:
/***/ ((module) => {

"use strict";
module.exports = require("react-bootstrap/Modal");

/***/ }),

/***/ 7518:
/***/ ((module) => {

"use strict";
module.exports = require("styled-components");

/***/ }),

/***/ 9648:
/***/ ((module) => {

"use strict";
module.exports = import("axios");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [893,801,872], () => (__webpack_exec__(4363)));
module.exports = __webpack_exports__;

})();